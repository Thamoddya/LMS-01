<div class="authors-box">
                    <div class="author-one"><img src="./assets/images/resource/author-2.jpg" alt="" /></div>
                    <div class="author-two"><img src="./assets/images/resource/author-3.jpg" alt="" /></div>
                    <div class="author-three"><img src="./assets/images/resource/author-4.jpg" alt="" /></div>
                    <div class="author-four"><img src="./assets/images/resource/author-5.jpg" alt="" /></div>

                    <div class="author-five"><img src="./assets/images/resource/author-6.jpg" alt="" /></div>
                    <div class="author-six"><img src="./assets/images/resource/author-7.jpg" alt="" /></div>
                    <div class="author-seven"><img src="./assets/images/resource/author-8.jpg" alt="" /></div>
                    <div class="author-eight"><img src="./assets/images/resource/author-9.jpg" alt="" /></div>
                </div>

                <div class="single-item-carousel owl-carousel owl-theme">

                    <!-- Testimonial Block Two -->
                    <div class="testimonial-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <div class="quote-icon"><i class="fa-solid fa-quote-right"></i></div>
                                <div class="image">
                                    <img src="./assets/images/resource/author-1.jpg" alt="" />
                                </div>
                            </div>
                            <div class="text">Neel Prasanna is a highly respected ICT teacher in Sri Lanka, known for providing a beautiful and professional teaching experience. He is considered the best ICT teaching brand in Sri Lanka and is highly respected in the ICT community</div>
                        </div>
                    </div>

                    <!-- Testimonial Block Two -->
                    <div class="testimonial-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <div class="image">
                                    <img src="./assets/images/resource/author-5.jpg" alt="" />
                                </div>
                            </div>
                            <div class="text">Neel Prasanna is a highly respected ICT teacher in Sri Lanka, known for providing a beautiful and professional teaching experience. He is considered the best ICT teaching brand in Sri Lanka and is highly respected in the ICT community</div>
                        </div>
                    </div>

                    <!-- Testimonial Block Two -->
                    <div class="testimonial-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <div class="image">
                                    <img src="./assets/images/resource/author-5.jpg" alt="" />
                                </div>
                            </div>
                            <div class="text">Neel Prasanna is a highly respected ICT teacher in Sri Lanka, known for providing a beautiful and professional teaching experience. He is considered the best ICT teaching brand in Sri Lanka and is highly respected in the ICT community</div>
                        </div>
                    </div>

                </div>