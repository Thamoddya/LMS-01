<section class="video-section" style="background-image: url(./assets/images/background/2.jpg)">
            <div class="auto-container">
                <a href="https://www.youtube.com/watch?v=4t27o8hjYYg" class="lightbox-image video-box"><span class="fa fa-play"><i class="ripple"></i></span></a>
                <h4>Watch Intro Video</h4>
            </div>
        </section>