<div class="content-boxed">
    <div class="inner-column">
        <h1>Advanced Level <br>Information & Communication Technology</h1>
        <div class="buttons-box">
            <a href="./Register.php" class="theme-btn btn-style-one"><span class="txt">Get Stared <i class="fa fa-angle-right"></i></span></a>
            <a href="course.php" class="theme-btn btn-style-two"><span class="txt">All Courses <i class="fa fa-angle-right"></i></span></a>
        </div>
    </div>
</div>