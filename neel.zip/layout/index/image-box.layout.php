<!-- <div class="image titlt" data-tilt data-tilt-max="4">
    <div class="inner-column parallax-scene-1">
        <div class="image parallax-layer" data-depth="0.10">
            <img src="./assets/images/resource/banner.png" alt="NeelICT" />
        </div>
    </div>
</div> -->
<Section>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <div class="image titlt" data-tilt data-tilt-max="4">
                    <!-- <img src="./assets/images/resource/banner.png" alt="NeelICT" /> -->
                    <div class="inner-column parallax-scene-1">
                        <div class="image parallax-layer" data-depth="0.10">
                            <img  class="imageMainBorder" src="./assets/images/background/coursalimg1.jpg" alt="NeelICT" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="image titlt" data-tilt data-tilt-max="4">
                    <!-- <img src="./assets/images/resource/banner.png" alt="NeelICT" /> -->
                    <div class="inner-column parallax-scene-1">
                        <div class="image parallax-layer" data-depth="0.10">
                            <img class="imageMainBorder" src="./assets/images/background/coursalimg2.jpg" alt="NeelICT" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="image titlt" data-tilt data-tilt-max="4">
                    <!-- <img src="./assets/images/resource/banner.png" alt="NeelICT" /> -->
                    <div class="inner-column parallax-scene-1">
                        <div class="image parallax-layer" data-depth="0.10">
                            <img class="imageMainBorder" src="./assets/images/background/coursalimg3.jpg" alt="NeelICT" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</Section>