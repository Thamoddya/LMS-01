<div class="title-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <!-- Sec Title -->
                            <div class="sec-title">
                                <h2>Our Latest blog posts</h2>
                                <div class="text">Neel Prasanna is a highly respected ICT teacher in Sri Lanka, known for providing a beautiful and professional teaching experience. He is considered the best ICT teaching brand in Sri Lanka and is highly respected in the ICT community</div>
                            </div>
                            <a href="#" class="theme-btn btn-style-three"><span class="txt">All Blog Post <i class="fa fa-angle-right"></i></span></a>
                        </div>
                    </div>

                    <!-- News Column -->
                    <div class=" col-lg-6 col-md-12 col-sm-12 ">
                        <div id="carousel" class="carousel">

                            <div id='iten_1' class="hideLeft">
                                <img src="./assets/images/background/coursalimg1.jpg">
                            </div>

                            <div id='item_2' class="prevLeftSecond">
                                <img src="./assets/images/background/coursalimg2.jpg">
                            </div>

                            <div id='item_3' class="prev">
                                <img src="./assets/images/background/coursalimg3.jpg">
                            </div>

                            <div id='item_4' class="selected">
                                <img src="./assets/images/background/coursalimg4.jpg">
                            </div>

                            <div id='item_5' class="next">
                                <img src="./assets/images/background/coursalimg5.jpg">
                            </div>

                            <div id='item_6' class="nextRightSecond">
                                <img src="./assets/images/background/coursalimg6.jpg">
                            </div>

                            <div id='item_7' class="hideRight">
                                <img src="./assets/images/background/coursalimg1.jpg">
                            </div>

                            <div id='item_8' class="hideRight">
                                <img src="./assets/images/background/coursalimg2.jpg">
                            </div>
                        </div>

                        <div class="buttons">
                            <div id="prev">
                            </div>
                            <div id="next">
                            </div>
                        </div>
                    </div>