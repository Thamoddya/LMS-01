

<div class="blocks-outer">

                            <!-- Event Block -->
                            <div class="event-block">
                                <div class="inner-box">
                                    <div class="clearfix">
                                        <!-- Event Date -->
                                        <div class="event-date clearfix"><span class="date">01</span>JUNE 1 2023</div>
                                        <!-- Event List -->
                                        <ul class="event-list">
                                            <li><a href="course-detail.html">EDUCATION & KNOWLEDGE</a></li>
                                            <li><a href="course-detail.html">TALK</a></li>
                                        </ul>
                                    </div>
                                    <h3><a href="course-detail.html">KAIYA with NEELICT</a></h3>
                                </div>
                            </div>

                            <!-- Event Block -->
                            <div class="event-block">
                                <div class="inner-box">
                                    <div class="clearfix">
                                        <!-- Event Date -->
                                        <div class="event-date clearfix"><span class="date">30</span>Mar 2020</div>
                                        <!-- Event List -->
                                        <ul class="event-list">
                                            <li><a href="course-detail.html">EDUCATION & KNOWLEDGE</a></li>
                                            <li><a href="course-detail.html">TALK</a></li>
                                        </ul>
                                    </div>
                                    <h3><a href="course-detail.html">KAIYA with NEELICT EP 04</a></h3>
                                </div>
                            </div>

                            <!-- Event Block -->
                            <div class="event-block">
                                <div class="inner-box">
                                    <div class="clearfix">
                                        <!-- Event Date -->
                                        <div class="event-date clearfix"><span class="date">25</span>JUNE 25 2023</div>
                                        <!-- Event List -->
                                        <ul class="event-list">
                                            <li><a href="course-detail.html">EDUCATION</a></li>
                                            <li><a href="course-detail.html">NEW CLASS STARTING</a></li>
                                        </ul>
                                    </div>
                                    <h3><a href="course-detail.html">2025 TECH Maharagama - OSIS</a></h3>
                                </div>
                            </div>
                        </div>