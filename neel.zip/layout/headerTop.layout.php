<div class="header-top">
    <div class="auto-container">
        <div class="clearfix">

            <!-- Top Left -->
            <div class="top-left pull-left clearfix">

                <!-- Info List -->
                <ul class="info-list">
                    <li><span>Call Us:</span><a href="tel:071 523 8348"> 071 523 8348</a></li>
                    <li><span>Email Us:</span><a href="mailto:n3neel@gmail.com"> n3neel@gmail.com</a></li>
                </ul>

            </div>

            <!-- Top Right -->
            <div class="top-right pull-right clearfix">
                <!-- Login Nav -->
                <ul class="login-nav">
                    <li><a href="login.php">Log In</a></li>
                    <li><a href="register.php">Register</a></li>
                </ul>
            </div>

        </div>
    </div>
</div>