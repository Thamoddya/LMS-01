<div class="mobile-menu">
    <div class="menu-backdrop"></div>
    <div class="close-btn"><i class="fa-solid fa-xmark"></i></div>

    <nav class="menu-box">
        <div class="nav-logo"><a href="index.html"><img src="./assets/images/logo-5.png" alt="neelict" title="NEEL ICT"></a></div>
        <div class="menu-outer">
        </div>
    </nav>
</div>