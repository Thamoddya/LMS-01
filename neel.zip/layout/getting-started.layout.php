<section class="call-to-action-section-two" style="background-image: url(./assets/images/background/3.png)">
            <div class="auto-container">
                <div class="content">
                    <h2>Ready to get started?</h2>
                    <div class="text">Neel Prasanna is a highly respected ICT teacher in Sri Lanka, known for providing a beautiful and professional teaching experience. He is considered the best ICT teaching brand in Sri Lanka and is highly respected in the ICT community.<br>
                        Neel Prasanna has been teaching ICT for many years and has gained vast professional experience in the field. He has offered classes for AL students and has conducted ICT classes in Sinhala language.</div>
                    <div class="buttons-box">
                        <a href="course.html" class="theme-btn btn-style-one"><span class="txt">Get Stared <i class="fa fa-angle-right"></i></span></a>
                        <a href="course.html" class="theme-btn btn-style-two"><span class="txt">All Courses <i class="fa fa-angle-right"></i></span></a>
                    </div>
                </div>
            </div>
        </section>