<link href="./assets/css/bootstrap.css" rel="stylesheet">
<link href="./assets/css/main.css" rel="stylesheet">
<link href="./assets/css/responsive.css" rel="stylesheet">
<script src="https://kit.fontawesome.com/3840ac106f.js" crossorigin="anonymous"></script>

<link rel="shortcut icon" href="./assets/images/favicon.png" type="image/x-icon">
<link rel="icon" href="./assets/images/favicon.png" type="image/x-icon">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&family=Titillium+Web:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>