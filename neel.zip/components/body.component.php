<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-circle-up"></span></div>

<script src="./assets/js/jquery.js"></script>
<script src="./assets/js/popper.min.js"></script>
<script src="./assets/js/jquery.scrollTo.js"></script>
<script src="./assets/js/bootstrap.min.js"></script>
<script src="./assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="./assets/js/jquery.fancybox.js"></script>
<script src="./assets/js/appear.js"></script>
<script src="./assets/js/swiper.min.js"></script>
<script src="./assets/js/element-in-view.js"></script>
<script src="./assets/js/jquery.paroller.min.js"></script>
<script src="./assets/js/parallax.min.js"></script>
<script src="./assets/js/tilt.jquery.min.js"></script>
<!--Master Sl./assets/ider-->
<script src="./assets/js/jquery.easing.min.js"></script>
<script src="./assets/js/magic_mouse.min.js"></script>
<script src="./assets/js/owl.js"></script>
<script src="./assets/js/wow.js"></script>
<script src="./assets/js/jquery-ui.js"></script>
<script src="./assets/js/script.js"></script>

<script type="text/javascript">
        options = {
            "cursorOuter": "circle-basic",
            "hoverEffect": "circle-move",
            "hoverItemMove": false,
            "defaultCursor": false,
            "outerWidth": 30,
            "outerHeight": 30
        };
        magicMouse(options);
    </script>