<!-- Sec Title -->
<div class="sec-title">
                          <h4>Student Home</h4>
                        </div>
                        <div class="container-fluid">
                          <div class="row">

                            <div
                              class="mt-1 mt-md-0 col-md-4 h-25 offset-md-1 d-flex justify-content-center align-items-center bg-secondary rounded-2 p-4 mb-3 mr-3">
                              <h5 class="text-white">Total Students : 500</h5>
                            </div>
                            <div
                              class="mt-1 mt-md-0 col-md-4 h-25 offset-md-2 d-flex justify-content-center align-items-center bg-secondary rounded-2 p-4 mb-3 mr-3">
                              <h5 class="text-white">Total Videos : 500</h5>
                            </div>
                            <div class="col-12 mt-1">
                              <h4>Latest Registed Students</h4>
                            </div>

                            <div class="col-12 mt-1 overflow-auto">
                              <?php
                              include_once "./admin.layouts/main.table1.php";
                              ?>
                            </div>

                          </div>
                        </div>
