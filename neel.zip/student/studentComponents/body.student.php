<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-circle-up"></span></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/jquery.scrollTo.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="../assets/js/jquery.fancybox.js"></script>
<script src="../assets/js/appear.js"></script>
<script src="../assets/js/swiper.min.js"></script>
<script src="../assets/js/element-in-view.js"></script>
<script src="../assets/js/jquery.paroller.min.js"></script>
<script src="../assets/js/parallax.min.js"></script>
<script src="../assets/js/tilt.jquery.min.js"></script>
<!--Master Sl./assets/ider-->
<script src="../assets/js/jquery.easing.min.js"></script>
<script src="../assets/js/owl.js"></script>
<script src="../assets/js/wow.js"></script>
<script src="../assets/js/jquery-ui.js"></script>
<script src="../assets/js/script.js"></script>
<script src="./student.assets/js/student.main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>