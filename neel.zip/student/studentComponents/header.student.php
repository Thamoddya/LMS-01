<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<link href="../assets/css/main.css" rel="stylesheet">
<link href="../assets/css/responsive.css" rel="stylesheet">
<script src="https://kit.fontawesome.com/3840ac106f.js" crossorigin="anonymous"></script>
<link href="https://vjs.zencdn.net/8.3.0/video-js.css" rel="stylesheet" />
<link rel="shortcut icon" href="../assets/images/favicon.png" type="image/x-icon">
<link rel="icon" href="../assets/images/favicon.png" type="image/x-icon">
<script src="https://vjs.zencdn.net/8.3.0/video.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&family=Titillium+Web:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>